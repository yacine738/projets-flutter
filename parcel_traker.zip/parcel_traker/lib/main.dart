import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:vector_math/vector_math_64.dart' as matrix4;

void main() => runApp(MaterialApp(
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    ));

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  bool result = false;
  String trackingStatus = "Order Placed"; // Example status

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          content(),
          body(),
        ],
      ),
    );
  }

  Widget content() {
    return Container(
      height: 300,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(50),
          bottomRight: Radius.circular(50),
        ),
      ),
      child: Column(
        children: [
          Image.network(
            "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT6Yc_N3xC9akfMD4yRs9kwCBKoaRrie9z-Rg&usqp=CAU",
            height: 200,
          ),
          Text(
            "Parcel Tracker",
            style: TextStyle(fontSize: 30),
          )
        ],
      ),
    );
  }

  Widget body() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 50),
        Padding(
          padding: const EdgeInsets.only(left: 35.0),
          child: Text(
            "Tracking number :",
            style: TextStyle(fontSize: 16),
          ),
        ),
        SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.fromLTRB(30, 0, 20, 0),
          child: Row(
            children: [
              Container(
                height: 60,
                width: 310,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(50),
                ),
                child: TextField(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "e.g #123456724564",
                    contentPadding: EdgeInsets.symmetric(horizontal: 20),
                  ),
                ),
              ),
              SizedBox(width: 10),
              GestureDetector(
                onTap: () {
                  setState(() {
                    result = true;
                  });
                },
                child: Icon(
                  Icons.search,
                  size: 35,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 20),
        if (result)
          Padding(
            padding: const EdgeInsets.fromLTRB(35, 2, 35, 0),
            child: Row(
              children: [
                Text(
                  "Result :",
                  style: TextStyle(fontSize: 25),
                ),
                Spacer(),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      result = false;
                    });
                  },
                  child: Icon(
                    Icons.close,
                    size: 25,
                  ),
                ),
              ],
            ),
          ),
        if (result)
          Padding(
            padding: const EdgeInsets.fromLTRB(15, 2, 15, 0),
            child: Text(
                "Tracking Status: $trackingStatus"), // Replaced VerticalStepper
          ),
        Transform(
          transform: matrix4.Matrix4.translationValues(0, -50, 0),
          child: Lottie.network(
              "https://assets2.lottiefiles.com/packages/lf20_t24tpvcu.json"),
        ),
      ],
    );
  }
}
