package com.example.parcel_traker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
