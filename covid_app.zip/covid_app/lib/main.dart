import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

void main() => runApp(MaterialApp(
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    ));

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: content(),
    );
  }
}

Widget content() {
  return SingleChildScrollView(
    child: Column(
      children: [
        Stack(
          children: [
            Container(
              height: 280,
              decoration: BoxDecoration(color: Colors.blue[100]),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10.0),
              child: Align(
                alignment: Alignment.center,
                child: Lottie.network(
                  "https://assets8.lottiefiles.com/private_files/lf30_4FGi6N.json",
                  animate: false,
                  width: 300,
                  height: 280,
                ),
              ),
            ),
          ],
        ),
        Transform(
          transform: Matrix4.translationValues(0, -47, 0),
          child: Text(
            "protégez-vous, protégez tout le monde",
            style:
                GoogleFonts.mavenPro(fontSize: 20, fontWeight: FontWeight.w500),
          ),
        ),
        Transform(
          transform: Matrix4.translationValues(0, -20, 0),
          child: Column(
            children: [
              Text(
                "Covid-19 Statistic",
                style: GoogleFonts.mavenPro(
                    fontSize: 28, fontWeight: FontWeight.w500),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "17/09/2021",
                    style: GoogleFonts.mavenPro(
                        fontSize: 18, fontWeight: FontWeight.w500),
                  ),
                  SizedBox(width: 10),
                  Icon(Icons.calendar_today),
                ],
              ),
              SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: stateBox(
                            color: Colors.red,
                            value: "+17577",
                            total: "2,067,327",
                            type: "Total",
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          flex: 1,
                          child: stateBox(
                            color: Colors.green,
                            value: "+22970",
                            total: "1,823,245",
                            type: "Recover",
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: stateBox(
                            color: Colors.yellow,
                            value: "-5781",
                            total: "221,339",
                            type: "Active",
                          ),
                        ),
                        SizedBox(width: 10),
                        Expanded(
                          flex: 1,
                          child: stateBox(
                            color: Colors.yellow[800]!,
                            value: "+388",
                            total: "22,743",
                            type: "Death",
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 15),
        Text(
          "Vaccine Statistic",
          style:
              GoogleFonts.mavenPro(fontSize: 28, fontWeight: FontWeight.w500),
        ),
        SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 1,
                    child: stateBox(
                      color: Colors.blue,
                      value: "3.7M",
                      total: "1st Dose",
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    flex: 1,
                    child: stateBox(
                      color: Colors.blue,
                      value: "18.1M",
                      total: "2nd Dose",
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),
              stateBox(
                color: Colors.blue,
                value: "56.8%",
                total: "Vaccine Rate",
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

Widget stateBox({
  required Color color,
  required String value,
  required String total,
  String? type,
}) {
  return Container(
    height: 100,
    width: 220,
    decoration: BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(20),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          value,
          style: GoogleFonts.mavenPro(
            fontSize: 30,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
        SizedBox(height: 10),
        Text(
          total,
          style: GoogleFonts.mavenPro(
            fontSize: 17,
            fontWeight: FontWeight.w500,
            color: Colors.white,
          ),
        ),
        if (type != null)
          Text(
            type,
            style: GoogleFonts.mavenPro(
              fontSize: 17,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
      ],
    ),
  );
}
